#include <SFML/Graphics.hpp>
#include <sstream>

using namespace sf;


int main()
{  
    RenderWindow window(VideoMode(400, 250), "SFML works!");

	Font font;
	font.loadFromFile("sansation.ttf");

	Text mytext("Hello!",font,50);
	
	mytext.setColor(Color::Green);
	mytext.setPosition(10,10);

	float q = 0.001;

    while (window.isOpen())
    { 

        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)      
                window.close();
		}
		 window.clear();

		  
	     std::ostringstream ss;    // #include <sstream>
		 ss<< q;
		 mytext.setString( ss.str() );
		 window.draw(mytext);

		 
		 window.display();
    }

    return 0;
}



